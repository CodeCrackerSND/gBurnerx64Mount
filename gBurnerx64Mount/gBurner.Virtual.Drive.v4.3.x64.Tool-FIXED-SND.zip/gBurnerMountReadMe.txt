gBurner Virtual Drive 4.1 and 4.3
gBurner Virtual Drive is free,
this is just a image mounter helper.

Installation note:
Copy gBurnerMount.exe to gBurner Virtual Drive path
ie. C:\Program Files\gBurner Virtual Drive
Import ImagesMountWith.reg to register iso, uif and nrg extension.

gBurnerMount will only mount the image to the first Drive of gBurner Virtual Drive.
Execute gBurnerMount.exe, browse for image by clicking "..." button,
and click on Mount button to mount the image.
You could also drag and drop the image to gBurnerMount.exe and will be
automatically mounted.

